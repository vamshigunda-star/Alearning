package com.example.alearning.ui.components

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.alearning.domain.repository.AiCoachStatus
import com.example.alearning.ui.aicoach.AiCoachViewModel

@Composable
fun AiFloatingActionButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: AiCoachViewModel = hiltViewModel()
) {
    val status by viewModel.status.collectAsState()

    // Only show the FAB if the device supports AICore and it's not in an error state
    if (status == AiCoachStatus.READY || status == AiCoachStatus.DOWNLOADING) {
        FloatingActionButton(
            onClick = onClick,
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = modifier.padding(16.dp)
        ) {
            Icon(Icons.Default.AutoAwesome, contentDescription = "Ask AI Coach")
        }
    }
}
