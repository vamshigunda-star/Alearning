package com.example.alearning.ui.aicoach

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.alearning.domain.repository.AiCoachRepository
import com.example.alearning.domain.repository.AiCoachStatus
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val isFromUser: Boolean
)

@HiltViewModel
class AiCoachViewModel @Inject constructor(
    private val aiCoachRepository: AiCoachRepository
) : ViewModel() {

    val status: StateFlow<AiCoachStatus> = aiCoachRepository.status

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    init {
        viewModelScope.launch {
            aiCoachRepository.checkAvailability()
        }
    }

    fun sendMessage(prompt: String, contextData: String? = null) {
        if (prompt.isBlank()) return

        val userMessage = ChatMessage(text = prompt, isFromUser = true)
        _messages.value = _messages.value + userMessage
        _isLoading.value = true

        viewModelScope.launch {
            val responseText = aiCoachRepository.sendMessage(prompt, contextData)
            val aiMessage = ChatMessage(text = responseText, isFromUser = false)
            _messages.value = _messages.value + aiMessage
            _isLoading.value = false
        }
    }
}
