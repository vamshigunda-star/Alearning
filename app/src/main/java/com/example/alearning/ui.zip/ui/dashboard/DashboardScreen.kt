package com.example.alearning.ui.dashboard

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.automirrored.filled.LibraryBooks
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.alearning.domain.model.testing.TestingEvent
import com.example.alearning.ui.components.AppTopBar
import com.example.alearning.ui.theme.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    modifier: Modifier = Modifier,
    onNavigateToRoster: () -> Unit,
    onNavigateToTestLibrary: () -> Unit,
    onNavigateToCreateEvent: () -> Unit,
    onNavigateToQuickTest: () -> Unit,
    onNavigateToTestingGrid: (String, String) -> Unit,
    onNavigateToLeaderboard: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToSignIn: () -> Unit = {},
    viewModel: DashboardViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(uiState.navigateToSignIn) {
        if (uiState.navigateToSignIn) {
            viewModel.onAction(DashboardAction.NavigationConsumed)
            onNavigateToSignIn()
        }
    }

    DashboardContent(
        modifier = modifier,
        uiState = uiState,
        onAction = {
            when (it) {
                DashboardAction.OnCreateEventClick -> onNavigateToCreateEvent()
                DashboardAction.OnQuickTestClick -> onNavigateToQuickTest()
                DashboardAction.OnRosterClick -> onNavigateToRoster()
                DashboardAction.OnTestLibraryClick -> onNavigateToTestLibrary()
                is DashboardAction.OnEventClick -> onNavigateToTestingGrid(it.eventId, it.groupId)
                DashboardAction.OnLeaderboardClick -> onNavigateToLeaderboard()
                DashboardAction.OnAnalyticsClick -> onNavigateToReports()
                DashboardAction.OnSeeAllEventsClick -> onNavigateToReports()
                else -> viewModel.onAction(it)
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardContent(
    modifier: Modifier = Modifier,
    uiState: DashboardUiState,
    onAction: (DashboardAction) -> Unit
) {
    Scaffold(
        modifier = modifier,
        topBar = {
            AppTopBar(
                title = "ALearning",
                actions = {
                    IconButton(onClick = { onAction(DashboardAction.OnSignOutClick) }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Logout,
                            contentDescription = "Sign out"
                        )
                    }
                }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 150.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = 16.dp,
                bottom = 80.dp
            ),
            verticalArrangement = Arrangement.spacedBy(20.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                ContextHeaderCard(
                    athleteCount = uiState.activeAthletes,
                    eventCount = uiState.scheduledTestCount,
                    coachFirstName = uiState.coachFirstName,
                    coachLastName = uiState.coachLastName
                )
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                HeroCard {
                    onAction(DashboardAction.OnCreateEventClick)
                }
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    "Quick Actions",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            item {
                QuickActionCard(
                    icon = Icons.Default.Bolt,
                    label = "Quick Test",
                    tint = SportOrange,
                    onClick = { onAction(DashboardAction.OnQuickTestClick) }
                )
            }
            item {
                QuickActionCard(
                    icon = Icons.Default.Group,
                    label = "Roster",
                    tint = SportBlue,
                    onClick = { onAction(DashboardAction.OnRosterClick) }
                )
            }
            item {
                QuickActionCard(
                    icon = Icons.AutoMirrored.Filled.LibraryBooks,
                    label = "Tests",
                    tint = MaterialTheme.colorScheme.primary,
                    onClick = { onAction(DashboardAction.OnTestLibraryClick) }
                )
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Recent Events",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    TextButton(onClick = { onAction(DashboardAction.OnSeeAllEventsClick) }) {
                        Text("See All")
                    }
                }
            }

            if (uiState.recentEvents.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    EmptyState(
                        icon = Icons.Default.Event,
                        title = "No recent events",
                        message = "Create one to get started!",
                        actionLabel = "Create Event",
                        onAction = { onAction(DashboardAction.OnCreateEventClick) }
                    )
                }
            } else {
                items(
                    items = uiState.recentEvents,
                    span = { GridItemSpan(maxLineSpan) }
                ) { event ->
                    RecentEventItem(
                        event = event,
                        onClick = {
                            event.groupId?.let {
                                onAction(DashboardAction.OnEventClick(event.id, it))
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun ContextHeaderCard(
    athleteCount: Int,
    eventCount: Int,
    coachFirstName: String,
    coachLastName: String
) {
    val greetingPrefix = remember {
        when (java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)) {
            in 5..11 -> "Good morning"
            in 12..16 -> "Good afternoon"
            else -> "Good evening"
        }
    }
    val displayName = listOf(coachFirstName, coachLastName)
        .filter { it.isNotBlank() }
        .joinToString(" ")
        .ifBlank { "Coach" }
    val greeting = "$greetingPrefix, $displayName"
    val dateStr = remember {
        SimpleDateFormat("EEEE, d MMM", Locale.getDefault())
            .format(Date())
    }

    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.elevatedCardColors(
            containerColor = NavyPrimary
        )
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                greeting,
                style = MaterialTheme.typography.headlineSmall,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "$athleteCount athletes · $eventCount events",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.8f)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                dateStr,
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.6f)
            )
        }
    }
}

@Composable
private fun HeroCard(onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize(),
        onClick = onClick,
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = SportOrange),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 24.dp, vertical = 20.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "Start Testing Event",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Select group → pick tests → begin",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.85f)
                )
            }
            Surface(
                modifier = Modifier.size(48.dp),
                shape = MaterialTheme.shapes.medium,
                color = Color.White.copy(alpha = 0.2f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Default.PlayArrow,
                        contentDescription = "Start",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }
    }
}



@Composable
private fun QuickActionCard(
    icon: ImageVector,
    label: String,
    tint: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    ElevatedCard(
        onClick = onClick,
        modifier = modifier.height(84.dp),
        shape = MaterialTheme.shapes.medium,
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                icon,
                contentDescription = label,
                tint = tint,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RecentEventItem(event: TestingEvent, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick,
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = formatEventDate(event.date, event.name),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f)
            )
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "Details",
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
        }
    }
}

private fun formatEventDate(timestamp: Long, eventName: String): String {
    val calendar = Calendar.getInstance().apply { timeInMillis = timestamp }
    val today = Calendar.getInstance()
    val yesterday = Calendar.getInstance().apply { add(Calendar.DATE, -1) }

    val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())

    val dayString = when {
        calendar.get(Calendar.YEAR) == today.get(Calendar.YEAR) && calendar.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR) -> "Today"
        calendar.get(Calendar.YEAR) == yesterday.get(Calendar.YEAR) && calendar.get(Calendar.DAY_OF_YEAR) == yesterday.get(Calendar.DAY_OF_YEAR) -> "Yesterday"
        else -> SimpleDateFormat("MMMM d", Locale.getDefault()).format(calendar.time)
    }

    return "$dayString, ${timeFormat.format(calendar.time)} • $eventName"
}

@Composable
fun EmptyState(
    icon: ImageVector,
    title: String,
    message: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                icon,
                contentDescription = null,
                modifier = Modifier.size(64.dp),
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            if (actionLabel != null && onAction != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = onAction,
                    shape = MaterialTheme.shapes.large
                ) {
                    Text(actionLabel)
                }
            }
        }
    }
}

@Preview
@Composable
private fun DashboardContentPreview() {
    AlearningTheme {
        DashboardContent(
            uiState = DashboardUiState(
                activeAthletes = 25,
                scheduledTestCount = 4,
                recentEvents = listOf(
                    TestingEvent(
                        id = "1",
                        name = "Max-Out Day",
                        date = System.currentTimeMillis() - 86400000,
                        groupId = "1",
                    ),
                    TestingEvent(
                        id = "2",
                        name = "Combine Prep",
                        date = System.currentTimeMillis() - 86400000 * 2,
                        groupId = "2",
                    )
                )
            ),
            onAction = {}
        )
    }
}
